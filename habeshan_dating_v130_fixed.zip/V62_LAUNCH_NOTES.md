# V62 — Real Email System

- provider-ready transactional email, verification/reset delivery, email templates, delivery logs
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
