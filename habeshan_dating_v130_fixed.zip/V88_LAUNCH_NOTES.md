# V88 — Partnership Network

Partner organizations and event-partnership foundation.

External providers remain disabled until real production credentials are configured.
