# Habeshan Dating V10 — Launch Experience

V10 builds on V9 with a more polished public-facing launch experience.

## Included
- V10 branding/version metadata
- Stronger homepage hero and calls to action
- Clear 18+ positioning
- Four-step onboarding explanation
- Safety-first presentation
- Mobile-responsive launch sections
- `/api/v10/features` feature manifest
- Existing V9 auth, discovery, matching, messaging, reporting, admin and security foundations retained

## Important
This is still a deployable starter, not a claim that external providers are connected.
Before public launch, configure and test PostgreSQL, transactional email, cloud image storage, payments, DNS/HTTPS, monitoring/backups, moderation workflows, legal pages, and production secrets.

## Run locally
```bash
npm install
npm start
```
