# V22 Production Checklist

- [ ] Set a real `BASE_URL` so invite links and sitemap URLs use the production domain.
- [ ] Configure HTTPS and secure cookies in production.
- [ ] Configure production email delivery and verify links.
- [ ] Test referral registration with a new account.
- [ ] Test referral completion after email verification.
- [ ] Confirm exactly one reward is issued per completed referral.
- [ ] Add anti-abuse limits before public growth campaigns.
- [ ] Configure Stripe keys/webhooks if monetization is enabled.
- [ ] Configure durable photo storage and database backups.
- [ ] Verify `/robots.txt` and `/sitemap.xml` on the production domain.
- [ ] Test Web Share and clipboard fallbacks on Android/iOS browsers.
- [ ] Run `npm run check` and review the launch notes before deployment.
