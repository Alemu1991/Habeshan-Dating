# Habeshan Dating V46

## Advanced Discovery

This is a real code release built from V45. It adds the V46 foundation and preserves previous features. External providers are configuration-dependent and are **not connected automatically**.

### Included
- Versioned API endpoints under `/api/v46/`
- Production-oriented configuration and documentation
- Backward-compatible continuation of the previous release

### Important
Configure secrets and external services in your deployment environment before production. Never commit API keys, database passwords, JWT secrets, Stripe secrets, or VAPID private keys.
