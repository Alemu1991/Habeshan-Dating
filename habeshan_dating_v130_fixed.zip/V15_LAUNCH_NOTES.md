# Habeshan Dating V15

## New
- Mobile-first swipe discovery with pointer drag gestures
- Like/pass/save/view controls
- Match celebration modal with direct message action
- Unread notification count endpoint
- Chat list presentation for matches
- V15 feature/status metadata

## Production notes
- Real-time Socket.IO remains available for messaging/typing.
- Payment, email, storage, identity verification and production database providers still require provider configuration and testing.
