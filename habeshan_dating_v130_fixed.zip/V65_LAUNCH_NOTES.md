# V65 — Real Push Notifications

- web-push subscription management, notification queue, provider diagnostics, notification center
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
