# V11 Production Checklist

- [ ] Managed PostgreSQL configured and migration applied
- [ ] HTTPS + DNS + production BASE_URL
- [ ] Strong secrets stored outside source control
- [ ] Transactional email configured and domain authenticated
- [ ] Cloud photo storage configured with private/public access rules tested
- [ ] Payment checkout + signed webhook configured and tested
- [ ] Admin MFA enabled
- [ ] Profile verification workflow reviewed by moderators
- [ ] Abuse/report queue tested
- [ ] Rate limits and daily like limits tested
- [ ] Account deletion and retention policy verified
- [ ] Backups and restore drill completed
- [ ] Monitoring/error alerts configured
- [ ] Mobile and slow-network testing completed
- [ ] Closed beta completed before public launch
