# V69 — Growth Engine

- referral attribution, onboarding funnel, campaign links, analytics dashboard, retention events
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
