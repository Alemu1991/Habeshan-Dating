# Habeshan Dating V16

V16 focuses on a more production-like realtime dating experience.

## Added
- Multiple profile photo gallery with up to 6 uploads per request.
- Photo deletion and gallery ordering API.
- Presence heartbeat, online status and last-seen display.
- Socket.IO realtime typing indicators.
- Realtime message and match notifications with optional browser Notification API.
- Read-receipt events and double-check indicators for sent messages.
- Persistent mobile bottom navigation for Discover, Matches, Chat, Alerts and Profile.
- `/api/v16/features` feature manifest.
- Version metadata and health endpoint updated to 16.0.0.

## Production note
The notification UI is browser-permission based and Socket.IO based. A production mobile app/PWA may add a Web Push service (VAPID/FCM/APNs) separately.
