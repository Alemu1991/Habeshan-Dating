# V101–V110 Launch Notes

Run `npm run check` first. Configure production environment variables, HTTPS, database, email, storage, payments, push, and backup providers before treating the launch gate as production-ready.

V110 exposes `/api/v110/launch-gate` for an authenticated admin preflight.
