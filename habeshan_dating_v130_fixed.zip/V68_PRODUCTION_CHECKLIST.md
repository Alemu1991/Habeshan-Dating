# V68 Production Checklist

- [ ] Capacitor-ready Android/iOS project configuration, mobile API config, deep-link foundation
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
