# V70 Production Checklist

- [ ] final launch gate, operational dashboard, incident readiness, backups, release manifest
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
