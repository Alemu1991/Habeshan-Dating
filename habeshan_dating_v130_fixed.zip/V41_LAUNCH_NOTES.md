# Habeshan Dating V41

## Real Cloud Deployment

This is a real code release built from V40. It adds the V41 foundation and preserves previous features. External providers are configuration-dependent and are **not connected automatically**.

### Included
- Versioned API endpoints under `/api/v41/`
- Production-oriented configuration and documentation
- Backward-compatible continuation of the previous release

### Important
Configure secrets and external services in your deployment environment before production. Never commit API keys, database passwords, JWT secrets, Stripe secrets, or VAPID private keys.
