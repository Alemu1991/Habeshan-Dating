# V70 — Habeshan Dating Live

- final launch gate, operational dashboard, incident readiness, backups, release manifest
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
