# Habeshan Dating V50

## Habeshan Dating 3.0

This is a real code release built from V49. It adds the V50 foundation and preserves previous features. External providers are configuration-dependent and are **not connected automatically**.

### Included
- Versioned API endpoints under `/api/v50/`
- Production-oriented configuration and documentation
- Backward-compatible continuation of the previous release

### Important
Configure secrets and external services in your deployment environment before production. Never commit API keys, database passwords, JWT secrets, Stripe secrets, or VAPID private keys.
