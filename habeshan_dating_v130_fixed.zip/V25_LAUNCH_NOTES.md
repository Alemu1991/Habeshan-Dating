# Habeshan Dating V25 — Experience Edition
- Responsive visual refresh for the app shell.
- Light, dark and system theme modes.
- Compact layout option.
- Reduced-motion accessibility option.
- Focus-outline accessibility helper.
- Lazy loading for later images.
- Account-saved UI preferences.
- `/api/v25/preferences` and `/api/v25/features`.
