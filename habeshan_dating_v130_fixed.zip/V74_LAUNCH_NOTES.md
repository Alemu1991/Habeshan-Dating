# Habeshan Dating V74 — AI Safety & Moderation

This release is cumulative from the previous build.

## Included
- AI Safety & Moderation
- Existing V61–V73 capabilities retained.
- Provider integrations remain credential-gated; no external service is silently connected.

## API
- `/api/v74/features`
