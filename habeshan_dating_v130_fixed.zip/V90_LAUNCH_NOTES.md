# V90 — International Scale Edition

Consolidated V81–V89 release and production launch gate.

External providers remain disabled until real production credentials are configured.
