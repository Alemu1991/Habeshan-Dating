# Habeshan Dating V8 Launch Plan

V8 is the bridge from a local starter to a deployable service.

## Included
- Production environment template
- PostgreSQL connection configuration
- `/healthz` health endpoint
- Deployment manifest example
- Production Docker Compose with PostgreSQL
- Payment webhook boundary
- Provider status endpoint
- Existing account, matching, messaging, moderation and admin flows

## Still requires real provider setup
1. Create a production PostgreSQL database.
2. Set a strong JWT secret in the deployment secret manager.
3. Configure a real email provider and domain authentication.
4. Configure S3-compatible object storage and CDN.
5. Choose a payment provider that legally supports your business and target market.
6. Implement and test signed payment webhooks.
7. Configure HTTPS/domain/DNS.
8. Enable admin MFA and separate moderator roles.
9. Complete privacy, terms, community guidelines and deletion/export procedures.
10. Run security, abuse, load and backup-restore tests.

V8 intentionally does not contain fake credentials or pretend that external accounts have been created.
