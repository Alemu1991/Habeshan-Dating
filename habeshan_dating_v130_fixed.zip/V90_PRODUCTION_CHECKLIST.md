# V90 Production Checklist

- [ ] Configure production secrets
- [ ] Configure database/storage/email providers
- [ ] Run migrations and backups
- [ ] Run security and launch preflight
- [ ] Test the V90 endpoints in staging
