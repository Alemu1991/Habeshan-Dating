# V65 Production Checklist

- [ ] web-push subscription management, notification queue, provider diagnostics, notification center
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
