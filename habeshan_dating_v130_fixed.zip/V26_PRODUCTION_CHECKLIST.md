# V26 Production Checklist

- [ ] Set a unique `JWT_SECRET`.
- [ ] Set `NODE_ENV=production`.
- [ ] Set an HTTPS `BASE_URL`.
- [ ] Configure `COOKIE_DOMAIN` only if appropriate for the deployment.
- [ ] Configure a real email provider and test verification/reset mail.
- [ ] Configure durable object storage for profile photos.
- [ ] Implement and verify a PostgreSQL runtime adapter/migrations before using managed Postgres.
- [ ] Configure Stripe secret, prices and webhook secret; test webhooks in a non-production environment first.
- [ ] Run `/api/admin/preflight` as an admin and resolve all production issues.
- [ ] Confirm `/healthz` returns HTTP 200.
- [ ] Run `npm run backup` and verify the backup artifact is restorable.
- [ ] Configure HTTPS at the reverse proxy/load balancer.
- [ ] Review rate limits, upload limits and moderation/report workflows.
- [ ] Test login, logout, logout-all and password reset.
- [ ] Test mobile/PWA installation and notification behavior.
- [ ] Perform an end-to-end smoke test with a test account before opening registration publicly.
