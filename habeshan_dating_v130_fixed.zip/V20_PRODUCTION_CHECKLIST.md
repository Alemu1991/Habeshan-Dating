# V20 Production Checklist

- [ ] Use a strong random `JWT_SECRET`; never use the development default.
- [ ] Set `NODE_ENV=production` and `TRUST_PROXY=true` when behind a trusted proxy.
- [ ] Use PostgreSQL/managed persistence for a multi-instance production deployment; do not rely on local SQLite for scale.
- [ ] Configure object storage/CDN for uploaded photos.
- [ ] Configure a real transactional email provider and test verification/reset emails.
- [ ] Configure Stripe test keys and recurring Prices.
- [ ] Configure the Stripe webhook secret and verify signed webhook delivery.
- [ ] Test checkout success, cancellation, duplicate webhook delivery, subscription cancellation and payment failure.
- [ ] Replace starter Terms, Privacy and Community Guidelines with counsel-reviewed documents for the jurisdictions served.
- [ ] Add backups, restore drills, monitoring and error tracking.
- [ ] Review moderation/report escalation procedures before public launch.
- [ ] Run mobile/PWA install testing on target Android devices and browsers.
- [ ] Run load/security tests before opening registration publicly.
