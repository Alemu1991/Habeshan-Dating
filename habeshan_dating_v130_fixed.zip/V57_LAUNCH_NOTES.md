V57 adds a production-ready local event model with creation, capacity limits, RSVP states and event chat access.
