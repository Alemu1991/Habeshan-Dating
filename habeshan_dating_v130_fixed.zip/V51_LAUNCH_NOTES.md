# Habeshan Dating V51 — Real Production Deployment

V51 turns the existing V40/V50 deployment foundation into a repeatable production workflow.

## Included
- PostgreSQL migration runner with schema migration tracking
- Production preflight command
- GitHub Actions production validation
- Render deployment manifest
- V51 deployment metadata migration
- Clean production environment template
- Existing Docker/health-check/PWA/payment foundations retained

## Important
This package does **not** connect to a cloud provider automatically. Set real secrets, create the managed PostgreSQL database, configure storage/email/payment providers, then run `npm run migrate:apply` and deploy.

## Commands
```bash
npm ci
npm run check
npm run preflight
npm run migrate:status
npm run migrate:apply
```

The application still uses its existing runtime database implementation; the V51 migration tooling prepares PostgreSQL safely for the production database adapter work. Do not point a live multi-instance deployment at PostgreSQL until the runtime adapter has been enabled and tested.
