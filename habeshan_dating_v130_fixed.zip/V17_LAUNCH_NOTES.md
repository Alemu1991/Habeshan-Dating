# Habeshan Dating V17

## New in V17
- Richer profile fields: occupation, education, languages and interests
- Profile completion percentage
- Drag-and-drop profile photo ordering
- Arrow controls for photo ordering on mobile
- First gallery photo remains the main profile photo
- Realtime read-receipt updates in open chats
- Reconnect realtime chat immediately after login
- Chat header name persists while sending messages
- Stronger server-side validation for photo reorder requests
- `/api/v16/features` reports V17 capabilities and version 17.0.0

## Production note
V17 remains a starter application. Before public launch, configure production email, database, object storage, HTTPS, backups, monitoring and a real Web Push provider.
