# V95 Production Checklist

- Run `node --check server.js`
- Configure production secrets and external providers where required
- Exercise the V95 endpoints in staging
- Review privacy, safety, and access controls
- Verify backups, monitoring, and rollback
