# V19 Production Checklist

- [ ] Configure a real payment provider adapter.
- [ ] Verify webhook signatures and replay protection.
- [ ] Make subscription state webhook-driven rather than client-trusted.
- [ ] Store provider customer/subscription/payment IDs.
- [ ] Add refund, cancellation and failed-payment handling.
- [ ] Test monthly and yearly plans in provider sandbox mode.
- [ ] Confirm boost entitlement is server-side and time-limited.
- [ ] Confirm Super Like allowance is enforced server-side.
- [ ] Add billing receipts/invoices where required.
- [ ] Review pricing, taxes, consumer disclosures and cancellation terms for the launch jurisdiction.
- [ ] Back up the production database before enabling real payments.
