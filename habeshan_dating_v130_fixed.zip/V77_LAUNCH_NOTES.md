# Habeshan Dating V77 — Ethiopian Dating Network

This release is cumulative from the previous build.

## Included
- Ethiopian Dating Network
- Existing V61–V76 capabilities retained.
- Provider integrations remain credential-gated; no external service is silently connected.

## API
- `/api/v77/features`
