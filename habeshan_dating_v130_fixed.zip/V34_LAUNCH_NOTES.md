# Habeshan Dating V34

## Safety & Trust

- Safety center
- Verification requests
- Privacy controls
- Safety events

This release builds on the previous version. Configure external providers and test in a staging environment before production launch.
