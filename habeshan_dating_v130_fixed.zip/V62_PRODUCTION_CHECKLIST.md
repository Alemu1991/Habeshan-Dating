# V62 Production Checklist

- [ ] provider-ready transactional email, verification/reset delivery, email templates, delivery logs
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
