# Habeshan Dating V22 — Launch Notes

V22 is the growth edition built on V21.

## New in V22
- Personal referral codes for every account
- Shareable invite links using `?ref=CODE`
- Referral attribution at registration
- Referral completion after email verification
- One 30-minute profile boost reward for each verified referral
- Referral dashboard with total and verified counts
- Copy/share invite actions using the Web Share API when available
- Referral-code regeneration
- SEO-friendly `robots.txt` and `sitemap.xml` routes
- `/api/v22/features` capability metadata
- Updated PWA shell cache/version metadata
- V22 launch documentation

## Safety/abuse notes
Referral rewards should be monitored for abuse before a large public launch. For a production deployment, consider email/phone verification, IP/device rate limits, duplicate-account detection and reward caps.

## Payment note
V22 does not change the existing Stripe configuration. Real payments remain controlled by the V20/V21 production environment and webhook setup.
