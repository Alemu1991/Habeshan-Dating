# V66 Production Checklist

- [ ] risk scoring, IP/device throttling, suspicious activity logs, safety controls, admin review
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
