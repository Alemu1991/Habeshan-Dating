# Habeshan Dating V11 — Production Integration Starter

V11 builds on V10 and adds explicit production integration boundaries and safety controls.

## Added
- V11 feature manifest endpoint: `/api/v11/features`
- Profile verification request workflow boundary
- Configurable daily-like limit
- Moderation/verification environment controls
- Message-reporting configuration boundary
- Production provider boundaries retained for email, storage and payments
- Updated version metadata and launch documentation

## Production integrations still require merchant/provider accounts
The project intentionally does not invent API credentials or claim that external services are connected.
Configure and test:
- Transactional email provider
- Cloud object storage/CDN
- Payment provider and signed webhooks
- Managed PostgreSQL
- Optional phone verification
- Identity/profile verification provider
- Monitoring, backups and moderation operations

## Security
Before public launch, test rate limits, session revocation, password reset, upload validation, authorization, webhook signatures, admin MFA, privacy/data deletion, and abuse reporting.

## Run
```bash
npm install
npm start
```
