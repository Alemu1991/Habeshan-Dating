# V9 Go-Live Checklist

## Required before real users
- [ ] Create managed PostgreSQL and run `migrations/001_initial_postgres.sql`
- [ ] Implement/switch the server repository from SQLite to PostgreSQL before horizontal scaling
- [ ] Set a unique JWT secret in a secret manager
- [ ] Configure HTTPS, DNS and `BASE_URL`
- [ ] Configure transactional email and authenticate the sending domain
- [ ] Configure cloud image storage + CDN; do not expose local disk in a multi-instance deployment
- [ ] Select a payment provider supported for the business and target markets
- [ ] Implement provider-specific checkout + signed webhook verification
- [ ] Enable admin MFA and create an admin role through a controlled bootstrap process
- [ ] Configure monitoring, backups and restore testing
- [ ] Run dependency/security scanning and penetration testing
- [ ] Review privacy, terms, age-gating, consumer, payment and online-safety obligations
- [ ] Test abuse reporting, moderation, account deletion and data retention
- [ ] Test rate limits, upload validation, session revocation and password reset
- [ ] Test mobile browsers and slow networks
- [ ] Complete a closed beta before public launch

## Not claimed as complete
This repository does not create third-party accounts, pass KYC, obtain legal approvals, or magically enable real payments. Those steps require the operator's business identity, credentials and provider-specific setup.
