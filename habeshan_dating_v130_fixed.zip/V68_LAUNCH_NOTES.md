# V68 — Mobile App Release

- Capacitor-ready Android/iOS project configuration, mobile API config, deep-link foundation
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
