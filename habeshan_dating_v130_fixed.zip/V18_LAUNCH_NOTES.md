# Habeshan Dating V18

V18 moves the V17 prototype toward a launch-ready foundation.

## Included
- Moderation dashboard with report queue and user account controls
- Report and block actions from profile views
- Suspend/restore account controls for admins
- Session revocation when an account is suspended
- PWA manifest and service worker offline shell
- Install prompt support on compatible browsers
- `/api/v18/features` capability endpoint
- Health endpoint version 18.0.0
- Existing authentication, verification, password reset boundary, rate limiting, Helmet, Socket.IO, gallery and realtime chat retained

## Important production work before public launch
- Replace the development email adapter with a real transactional email provider
- Use a strong `JWT_SECRET` and production secrets manager
- Put the app behind HTTPS and configure `TRUST_PROXY` correctly
- Move uploaded photos to durable object storage/CDN
- Move SQLite to a managed production database and complete migrations
- Add real payment provider integration before charging users
- Complete jurisdiction-specific Terms and Privacy Notice with legal review
- Add automated integration/e2e tests, backups, monitoring and alerting
- Add image moderation and abuse/spam controls appropriate for the launch region
- Configure a real Web Push provider if background notifications are required
