# V84 — Privacy & Consent

Consent ledger and privacy/data-control foundation.

External providers remain disabled until real production credentials are configured.
