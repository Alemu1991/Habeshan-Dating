# V29 Production Checklist

- [ ] Test install flow on Android Chrome and supported browsers.
- [ ] Configure production push provider if push notifications are required.
- [ ] Confirm service-worker cache invalidation after each release.
- [ ] Review app event retention/privacy policy.
