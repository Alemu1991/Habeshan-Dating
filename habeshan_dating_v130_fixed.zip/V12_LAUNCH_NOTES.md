# Habeshan Dating V12

V12 focuses on the user-facing dating experience.

## Highlights
- Mobile-first discovery card UI
- Swipe-style like/pass/message actions
- Advanced preference controls
- Verification badge presentation
- Online-status presentation
- Profile gallery-ready layout
- Read-receipt presentation
- Persistent mobile bottom navigation
- Existing V11 authentication, security, moderation, matching and messaging foundations retained

## Important
The visual discovery controls are a front-end experience layered over the existing API. Provider integrations (payments, email, storage, identity verification) still require real production credentials and testing.

Run:
```bash
npm install
npm start
```
