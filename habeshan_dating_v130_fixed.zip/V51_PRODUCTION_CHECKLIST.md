# V51 Production Checklist

- [ ] Domain DNS configured
- [ ] HTTPS enabled
- [ ] Managed PostgreSQL created
- [ ] `DATABASE_URL` stored as a secret
- [ ] `npm run migrate:apply` completed
- [ ] Cloud object storage configured for user photos
- [ ] Email provider configured
- [ ] Stripe production keys/webhook configured
- [ ] VAPID keys configured for push
- [ ] Strong `JWT_SECRET` configured
- [ ] `ADMIN_EMAIL` configured
- [ ] `npm run preflight` passes
- [ ] `/healthz` returns 200 after deployment
- [ ] Backup and restore tested
- [ ] Staging smoke test completed
- [ ] Runtime PostgreSQL adapter verified before multi-instance scaling
