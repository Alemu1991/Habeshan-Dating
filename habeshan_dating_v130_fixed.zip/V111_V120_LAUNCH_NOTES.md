# V111–V120 Launch Notes

V111–V120 adds the mobile/platform foundation. Before public launch, configure mobile release metadata, payment/currency providers, media storage, push delivery, AI provider if used, backup infrastructure, and the required Android/iOS publishing accounts.

V120 exposes `/api/v120/launch-gate` for an authenticated admin preflight.
