# V130 Production Checklist

- [ ] Node.js 20+ production runtime
- [ ] Strong JWT secret configured
- [ ] HTTPS `BASE_URL`
- [ ] Production database configured
- [ ] Email provider configured
- [ ] Media/storage provider configured
- [ ] Payment provider configured
- [ ] Push/VAPID credentials configured
- [ ] AI provider configured
- [ ] Identity provider configured
- [ ] Mobile release version configured
- [ ] Backup provider/restore process tested
- [ ] Human safety review process staffed
- [ ] Android/iOS store configuration completed
- [ ] Monitoring and incident response tested
