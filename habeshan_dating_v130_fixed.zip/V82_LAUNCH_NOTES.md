# V82 — Multi-Region Foundation

Regions, locale/timezone/currency preferences.

External providers remain disabled until real production credentials are configured.
