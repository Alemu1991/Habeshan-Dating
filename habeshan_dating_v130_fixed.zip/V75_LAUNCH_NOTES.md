# Habeshan Dating V75 — Voice & Video Dating foundation

This release is cumulative from the previous build.

## Included
- Voice & Video Dating foundation
- Existing V61–V74 capabilities retained.
- Provider integrations remain credential-gated; no external service is silently connected.

## API
- `/api/v75/features`
