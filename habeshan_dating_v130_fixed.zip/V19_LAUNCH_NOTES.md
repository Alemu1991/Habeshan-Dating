# Habeshan Dating V19 — Launch Notes

V19 adds a monetization layer while keeping payment-provider integration explicit and safe.

## Included
- Premium monthly and yearly membership records
- Demo checkout that never charges money
- Provider-ready billing boundary via `/api/billing/checkout`
- Subscription status endpoint with expiry handling
- 30-minute profile boosts for active premium members
- Super Likes with monthly allowance (1 basic / 5 premium)
- Boosted profiles are prioritized in discovery while a boost is active
- Premium status UI with plan, boost status and Super Like balance
- Premium feature section and mobile-friendly controls
- `/api/v19/features` feature metadata

## Important production note
The included checkout is a demo ledger only. Before accepting real money, integrate and test a supported payment provider, verify webhooks server-side, store provider transaction IDs, reconcile subscription state, and obtain the required legal/tax/compliance advice for the countries you serve.
