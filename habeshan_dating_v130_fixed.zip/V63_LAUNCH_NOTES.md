# V63 — Real Media Storage

- storage abstraction, local/S3-compatible provider configuration, upload diagnostics, media policy
- Set production secrets in .env or the hosting provider
- Run npm run check before deployment
- Run npm run preflight before launch

External providers remain disabled until the required production credentials are supplied.
