# Habeshan Dating V95

Global Discovery: country/region-aware discovery, distance-independent diaspora filters and discovery presets.

Provider integrations are configuration-ready; external services are not claimed as connected without credentials.
