# V83 — Language Layer

English, Amharic, Tigrinya, Oromo and Somali UI dictionary foundation.

External providers remain disabled until real production credentials are configured.
