# V30 Production Checklist

- [ ] Move production data to managed PostgreSQL.
- [ ] Move profile media to durable object storage/CDN.
- [ ] Configure transactional email and push providers.
- [ ] Configure monitoring, alerts, backups and restore drills.
- [ ] Load test before a public marketing campaign.
- [ ] Review privacy, retention and support processes.
