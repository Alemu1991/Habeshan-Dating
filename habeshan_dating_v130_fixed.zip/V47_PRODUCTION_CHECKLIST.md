# V47 Production Checklist

- [ ] Run `npm install`
- [ ] Run `npm run check`
- [ ] Configure `.env` from `.env.example`
- [ ] Configure managed PostgreSQL before multi-instance deployment
- [ ] Configure durable object storage for profile media
- [ ] Configure HTTPS and a production domain
- [ ] Configure email provider and verify sender domain
- [ ] Configure Stripe keys and webhook secret if billing is enabled
- [ ] Configure VAPID keys if web push is enabled
- [ ] Run staging smoke tests
- [ ] Back up database before release
- [ ] Review moderation, privacy and security controls
