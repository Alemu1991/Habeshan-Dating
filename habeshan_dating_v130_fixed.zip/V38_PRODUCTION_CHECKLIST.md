# V38 Production Checklist

- [ ] Run `npm install`
- [ ] Run `npm run check`
- [ ] Configure environment variables
- [ ] Configure persistent database/storage where required
- [ ] Test authentication, payments, messaging and moderation
- [ ] Test new V38 endpoints
- [ ] Run staging smoke tests
- [ ] Enable HTTPS and monitoring
- [ ] Back up the database before deployment
