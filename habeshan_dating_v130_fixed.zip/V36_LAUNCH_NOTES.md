# Habeshan Dating V36

## Events & Community

- Dating events
- Event rsvp
- Event discovery
- Event attendee foundation

This release builds on the previous version. Configure external providers and test in a staging environment before production launch.
