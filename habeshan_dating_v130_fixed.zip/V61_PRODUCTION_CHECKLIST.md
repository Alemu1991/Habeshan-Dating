# V61 Production Checklist

- [ ] production deployment readiness, environment validation, Docker/Render/Vercel-style manifests, deployment diagnostics
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
