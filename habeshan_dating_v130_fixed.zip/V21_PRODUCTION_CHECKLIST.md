# V21 Production Checklist

## Before launch
- [ ] Set a unique `JWT_SECRET`
- [ ] Set an HTTPS `BASE_URL`
- [ ] Configure a real email provider and `EMAIL_FROM`
- [ ] Configure durable object storage for uploaded photos
- [ ] Configure Stripe keys, prices and webhook secret if accepting payments
- [ ] Configure `ADMIN_EMAIL` and restrict admin access
- [ ] Put the app behind HTTPS/reverse proxy
- [ ] Configure database persistence and backups
- [ ] Run `npm run check`
- [ ] Run `npm run backup` and verify the backup can be restored
- [ ] Verify `/healthz` returns HTTP 200
- [ ] Log in as an admin and review `/api/admin/preflight`
- [ ] Test registration, email verification, password reset, matching, chat, reports, blocking and account deletion
- [ ] Test Stripe webhook delivery in the live environment before enabling paid plans

## Operational rule
Never place real secrets in source control. Store them in the hosting provider's secret/environment configuration.
