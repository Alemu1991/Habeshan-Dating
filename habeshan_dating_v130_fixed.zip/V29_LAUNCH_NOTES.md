# Habeshan Dating V29 — Mobile & PWA Edition

Adds install tracking, app event telemetry, mobile app status, and a stronger PWA/mobile presentation layer. Browser support varies; native push still requires provider configuration.
