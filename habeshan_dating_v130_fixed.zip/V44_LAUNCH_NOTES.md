# Habeshan Dating V44

## Advanced Chat

This is a real code release built from V43. It adds the V44 foundation and preserves previous features. External providers are configuration-dependent and are **not connected automatically**.

### Included
- Versioned API endpoints under `/api/v44/`
- Production-oriented configuration and documentation
- Backward-compatible continuation of the previous release

### Important
Configure secrets and external services in your deployment environment before production. Never commit API keys, database passwords, JWT secrets, Stripe secrets, or VAPID private keys.
