# V64 Production Checklist

- [ ] Stripe-ready checkout, billing portal foundation, subscription state, payment diagnostics
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
