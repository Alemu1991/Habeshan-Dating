# Habeshan Dating V20

V20 is the launch-hardening release. It keeps the V19 demo billing fallback but adds a real Stripe Checkout adapter that activates only when the required environment variables are present.

## Included
- Real Stripe Checkout Sessions for monthly/yearly subscriptions.
- Stripe webhook signature verification with a five-minute replay window.
- Pending subscription records and webhook-driven activation/cancellation/payment-failure states.
- Safe demo billing fallback when Stripe credentials are absent; demo mode never charges money.
- Payment success/cancel UI handling.
- Lightweight authenticated analytics events for product instrumentation.
- Health check verifies database availability.
- Graceful SIGINT/SIGTERM shutdown.
- V20 feature endpoint and production launch metadata.
- Existing V18 moderation/PWA and V19 premium features retained.

## Real payments setup
1. Create Stripe recurring Prices for monthly and yearly plans.
2. Set `STRIPE_SECRET_KEY`, `STRIPE_PRICE_MONTHLY`, `STRIPE_PRICE_YEARLY`, `STRIPE_WEBHOOK_SECRET`, and `BASE_URL`.
3. Configure the Stripe webhook endpoint as `/api/billing/webhook`.
4. Subscribe the webhook to `checkout.session.completed`, `customer.subscription.deleted`, and `invoice.payment_failed`.
5. Test in Stripe test mode before switching to live keys.

The application intentionally does not claim a successful payment until the signed webhook confirms the Checkout Session.
