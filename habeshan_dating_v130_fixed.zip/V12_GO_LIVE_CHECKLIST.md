# V12 GO-LIVE CHECKLIST

- [ ] Test discovery card behavior on iOS/Android-sized screens
- [ ] Connect discovery actions to production API routes
- [ ] Configure cloud image storage and image moderation
- [ ] Configure verification review process
- [ ] Test online status and read receipts with multiple accounts
- [ ] Test matching and unmatching
- [ ] Test block/report from profile and message surfaces
- [ ] Configure payments and signed webhooks
- [ ] Configure transactional email
- [ ] Complete security, privacy and legal review
