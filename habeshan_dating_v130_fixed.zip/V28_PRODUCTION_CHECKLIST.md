# V28 Production Checklist

- [ ] Review compatibility copy and privacy disclosures.
- [ ] Test scoring with diverse profiles.
- [ ] Add abuse/rate limits for feedback endpoints before large-scale traffic.
- [ ] Test mobile compatibility UI.
