# V67 Production Checklist

- [ ] Amharic/English/Tigrinya/Oromo/Somali/Afar labels, Ethiopian cities/currency/timezone settings
- [ ] Set production secrets in .env or the hosting provider
- [ ] Run npm run check before deployment
- [ ] Run npm run preflight before launch
