# Habeshan Dating V27 — Launch & Growth Edition

V27 adds the product-growth layer on top of V26 production foundations.

## Included
- V27 growth dashboard for admins
- Daily activity check-in and streak tracking
- Lightweight onboarding/profile-readiness tracking
- Notification preferences for email/push categories
- Share tracking for invites and platform sharing
- Referral growth retained from V22
- Community, recommendations, premium, messaging and moderation retained
- `/api/v27/features`
- `/api/v27/activity`
- `/api/v27/onboarding`
- `/api/v27/notification-preferences`
- `/api/v27/share-event`
- `/api/v27/growth`

## Important production notes
V27 records growth events in SQLite. It does not magically configure a production email/push provider. The preference layer is ready for a provider adapter, but actual outbound email/push delivery still requires a configured production service.
