# V27 Production Checklist

- [ ] Run `npm install`
- [ ] Set a strong `JWT_SECRET`
- [ ] Set `NODE_ENV=production`
- [ ] Set `BASE_URL` to the HTTPS domain
- [ ] Configure `COOKIE_DOMAIN` if needed
- [ ] Configure real email provider adapter before promising email delivery
- [ ] Configure real push/Web Push provider if push notifications are required
- [ ] Configure Stripe live keys and webhook secret
- [ ] Move profile uploads to durable object storage before multi-instance deployment
- [ ] Use a production database strategy; current runtime remains SQLite
- [ ] Run `npm run check`
- [ ] Run `npm run backup` and verify backups can be restored
- [ ] Test registration, verification, login, matching, messaging, referrals and moderation
- [ ] Test V27 daily activity and notification preferences on mobile
- [ ] Review privacy/terms/community guidelines before public launch
