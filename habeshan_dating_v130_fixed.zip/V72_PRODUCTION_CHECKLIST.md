# V72 Production Checklist

- [ ] Configure environment secrets for production
- [ ] Configure managed database and persistent media storage
- [ ] Configure email, payments, and push providers where needed
- [ ] Run `npm run check`
- [ ] Run `npm run preflight`
- [ ] Test authentication, matching, messaging, moderation, billing, and mobile flows
- [ ] Review logs and backups before launch
