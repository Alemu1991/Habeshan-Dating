# Habeshan Dating V26 — Production Launch Edition

V26 consolidates the launch-readiness work from V20–V25 and hardens the operational layer.

## Included
- Session revocation is now enforced by the authenticated session ID, not only the JWT.
- Session inactivity/age expiry is configurable with `SESSION_MAX_DAYS`.
- Logout revokes the current server-side session.
- Request IDs remain available for support and tracing.
- Production health endpoint reports application/database status.
- Admin preflight remains available at `/api/admin/preflight`.
- Admin operations summary is available at `/api/admin/ops`.
- `/api/v26/features` exposes launch capabilities.
- Cookie domain can be configured with `COOKIE_DOMAIN`.
- Existing PWA, moderation, referrals, community, discovery and premium systems are retained.

## Important production limitation
The current application still uses SQLite in `server.js`. `DATABASE_URL` is reported as configured for deployment checks, but a PostgreSQL adapter/migration must be implemented before treating PostgreSQL as the application's runtime database. Likewise, `STORAGE_PROVIDER=local` stores uploaded images on the container filesystem; use durable object storage before a multi-instance deployment.
