# V120 Production Checklist

- [ ] Node 20+
- [ ] Strong JWT secret
- [ ] HTTPS production BASE_URL
- [ ] Production PostgreSQL/DATABASE_URL
- [ ] Email provider
- [ ] Object/media storage provider
- [ ] Payment processor and signed webhooks
- [ ] Push/VAPID credentials
- [ ] AI provider credentials, if AI features are enabled
- [ ] Backup provider and tested restore procedure
- [ ] Android/iOS release configuration
- [ ] Human moderation and verification workflow staffed
- [ ] Monitoring and incident response
- [ ] Run `/api/v120/launch-gate` as an admin and resolve failed checks
